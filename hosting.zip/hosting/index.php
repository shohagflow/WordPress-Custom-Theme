<?php get_header(); ?>

<main id="site-main" class="site-main">
  <div class="container">
    <?php if ( have_posts() ) : ?>
      <div class="post-list">
        <?php while ( have_posts() ) : the_post(); ?>
          <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h2 class="post-title">
              <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h2>
            <div class="post-meta">
              <span>Posted on <?php echo get_the_date(); ?> by <?php the_author(); ?></span>
            </div>
            <div class="post-excerpt">
              <?php the_excerpt(); ?>
            </div>
          </article>
        <?php endwhile; ?>

        <div class="pagination">
          <?php the_posts_pagination(); ?>
        </div>
      </div>
    <?php else : ?>
      <p><?php esc_html_e( 'No posts found.', 'your-textdomain' ); ?></p>
    <?php endif; ?>
  </div>
</main>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
