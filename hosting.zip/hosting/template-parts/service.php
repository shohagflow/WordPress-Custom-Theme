<?php

// Template Name: Service
get_header();

?>
<!-- service section -->
<section class="service_section layout_padding">
    <div class="container">
        <?php
      $service_page_heading = get_field('service_page_heading');
      if(!empty($service_page_heading)): 
      ?>
        <div class="heading_container heading_center">
            <h2>
                <?php echo $service_page_heading; ?>
            </h2>
        </div>
        <?php endif; ?>
    </div>

    <div class="container ">
        <div class="row">
            <?php if(have_rows('service_page_repeater')): ?>
            <?php while(have_rows('service_page_repeater')): the_row(); 
      $service_page_icon = get_sub_field('service_page_icon'); // Font Awesome class (string)
      $service_page_name = get_sub_field('service_page_name');
      $service_page_description = get_sub_field('service_page_description');
      $service_page_button = get_sub_field('service_page_button');
    ?>
            <div class="col-md-6 col-lg-4">
                <div class="box">
                    <?php if(!empty($service_page_icon)): ?>
                    <div class="img-box">
                        <i class="<?php echo esc_attr($service_page_icon); ?>"></i>
                    </div>
                    <?php endif; ?>

                    <?php if($service_page_name || $service_page_description || $service_page_button): ?>
                    <div class="detail-box">
                        <?php if(!empty($service_page_name)): ?>
                        <h4><?php echo esc_html($service_page_name); ?></h4>
                        <?php endif; ?>

                        <?php if(!empty($service_page_description)): ?>
                        <p><?php echo esc_html($service_page_description); ?></p>
                        <?php endif; ?>

                        <?php if(!empty($service_page_button)): ?>
                        <a href="<?php echo esc_url($service_page_button['url']); ?>">
                            <?php echo esc_html($service_page_button['title']); ?>
                            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
        </div>


    </div>
</section>

<!-- end service section -->

<?php get_footer(); ?>