<?php

// Template Name: About
get_header();

?>

  <!-- about section -->
  <section class="about_section layout_padding background_color_class">
    <div class="container  ">
      <div class="row">
        <div class="col-md-6">
          <div class="detail-box">

            <?php
            $about_us_title = get_field('about_us_title');
            $about_us_description = get_field('about_us_description');
            $about_us_button = get_field('about_us_button');
            $about_us_image = get_field('about_us_image');
            
            if($about_us_title): ?>
            <div class="heading_container">
              <h2>
                 <?php echo $about_us_title;  ?>
              </h2>
            </div>
            <?php endif; ?>

          <?php if($about_us_description): ?>
            <p><?php echo $about_us_description;  ?></p>
             <?php endif; ?>

             <?php if($about_us_description): ?>
            <a href="<?php echo $about_us_button['url']; ?>">
              <?php echo $about_us_button['title']; ?>
            </a>
            <?php endif; ?>
          </div>
        </div>
      
        <div class="col-md-6 ">
            <?php if(!empty ($about_us_image['url'])): ?>
          <div class="img-box">
            <img src="<?php echo $about_us_image['url']; ?>" alt="">
          </div>
           <?php endif; ?>
        </div>      
      </div>
    </div>
  </section>
  <!-- end about section -->
<?php get_footer(); ?>