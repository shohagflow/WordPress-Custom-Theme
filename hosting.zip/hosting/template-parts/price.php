<?php

// Template Name: Price
get_header();

?>
<section class="price_section layout_padding">
    <div class="container">

        <?php 
    $price_titlee = get_field('price_titlee', get_the_ID());
    if ( ! empty( $price_titlee ) ) : ?>
        <div class="heading_container heading_center">
            <h2><?php echo esc_html( $price_titlee ); ?></h2>
        </div>
        <?php endif; ?>

        <div class="price_container">
            <?php if ( have_rows('price_box_repeater') ) : ?>
            <?php while ( have_rows('price_box_repeater') ) : the_row(); 
          $enter_price_p         = get_sub_field('enter_price_p');
          $enter_package_name_p  = get_sub_field('enter_package_name_p');
          $button_p              = get_sub_field('button_p'); // Link field
        ?>
            <div class="box">
                <div class="detail-box">
                    <?php if ( ! empty( $enter_price_p ) ) : ?>
                    <h2><?php echo esc_html( $enter_price_p ); ?></h2>
                    <?php endif; ?>

                    <?php if ( ! empty( $enter_package_name_p ) ) : ?>
                    <h6><?php echo esc_html( $enter_package_name_p ); ?></h6>
                    <?php endif; ?>

                    <ul class="price_features">
                        <?php if ( have_rows('package_details_repeater') ) : ?>
                        <?php while ( have_rows('package_details_repeater') ) : the_row(); 
                  $enter_package_p = get_sub_field('enter_package_p');
                  if ( ! empty( $enter_package_p ) ) : ?>
                        <li><?php echo esc_html( $enter_package_p ); ?></li>
                        <?php endif; ?>
                        <?php endwhile; ?>
                        <?php endif; ?>
                    </ul>
                </div>

                <?php if ( ! empty( $button_p['url'] ) && ! empty( $button_p['title'] ) ) : ?>
                <div class="btn-box">
                    <a href="<?php echo esc_url( $button_p['url'] ); ?>"
                        target="<?php echo esc_attr( $button_p['target'] ?: '_self' ); ?>">
                        <?php echo esc_html( $button_p['title'] ); ?>
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</section>


<?php get_footer();?>