<?php

// Template Name: Contact
get_header();

?>
<!-- contact section -->
<section class="contact_section layout_padding background_color_class">
    <div class="container">

        <?php
      $contact_from_title = get_field('contact_from_title');
      if ( ! empty( $contact_from_title ) ) : ?>
        <div class="heading_container heading_center">
            <h2><?php echo esc_html( $contact_from_title ); ?></h2>
        </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8 col-lg-6 mx-auto">
                <div class="form_container">
                    <?php echo do_shortcode( '[contact-form-7 id="2e77d12" title="Home page form"]'); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end contact section -->

<?php get_footer();?>