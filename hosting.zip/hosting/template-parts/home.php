<?php

// Template Name: Home
get_header();

?>
<div class="hero_area">
    <!-- slider section -->
    <section class="slider_section">
        <div id="customCarousel1" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <?php if ( have_rows('hero_section') ) : 
        $i = 0;
        while ( have_rows('hero_section') ) : the_row(); 
          $hero_heading     = get_sub_field('hero_headding');
          $hero_description = get_sub_field('hero_description');
          $button_1         = get_sub_field('button_1');
          $button_url1      = get_sub_field('button_url1');
          $button_2         = get_sub_field('button_2');
          $button_url2      = get_sub_field('button_url2');
          $hero_image       = get_sub_field('hero_image');
      ?>
                <div class="carousel-item <?php echo ($i === 0) ? 'active' : ''; ?>">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="detail-box">
                                    <?php if ( $hero_heading ) : ?>
                                    <h1><?php echo esc_html( $hero_heading ); ?></h1>
                                    <?php endif; ?>

                                    <?php if ( $hero_description ) : ?>
                                    <p><?php echo esc_html( $hero_description ); ?></p>
                                    <?php endif; ?>

                                    <div class="btn-box">
                                        <?php if ( $button_1 && $button_url1 ) : ?>
                                        <a href="<?php echo esc_url( $button_url1 ); ?>" class="btn-1">
                                            <?php echo esc_html( $button_1 ); ?>
                                        </a>
                                        <?php endif; ?>

                                        <?php if ( $button_2 && $button_url2 ) : ?>
                                        <a href="<?php echo esc_url( $button_url2 ); ?>" class="btn-2">
                                            <?php echo esc_html( $button_2 ); ?>
                                        </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <?php if ( ! empty( $hero_image['url'] ) ) : ?>
                            <div class="col-md-6">
                                <div class="img-box">
                                    <img src="<?php echo esc_url( $hero_image['url'] ); ?>"
                                        alt="<?php echo esc_attr( $hero_image['alt'] ); ?>">
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php 
        $i++;
        endwhile; 
      endif; ?>
            </div>

            <div class="carousel_btn-box">
                <a class="carousel-control-prev" href="#customCarousel1" role="button" data-slide="prev">
                    <i class="fa fa-angle-left" aria-hidden="true"></i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#customCarousel1" role="button" data-slide="next">
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </section>
    <!-- end slider section -->
</div>

<!-- service section -->
<?php if ( get_field('service_section_off') ) : ?>
<section class="service_section layout_padding">
    <div class="container">

        <?php 
    $service_heading = get_field('service_heading');
    if ( ! empty( $service_heading ) ) : ?>
        <div class="heading_container heading_center">
            <h2><?php echo esc_html( $service_heading ); ?></h2>
        </div>
        <?php endif; ?>

    </div>
    <div class="container ">
        <div class="row">
            <?php if ( have_rows('service_repeater') ) : ?>
            <?php while ( have_rows('service_repeater') ) : the_row(); 
      $service_icon        = get_sub_field('service_icon'); // Font Awesome class (ex: fa fa-server)
      $service_name        = get_sub_field('service_name');
      $service_description = get_sub_field('service_description');
      $service_button      = get_sub_field('service_button'); // Link field
    ?>
            <div class="col-md-6 col-lg-4">
                <div class="box">
                    <?php if ( ! empty( $service_icon ) ) : ?>
                    <div class="img-box">
                        <i class="<?php echo esc_attr( $service_icon ); ?>" aria-hidden="true"></i>
                    </div>
                    <?php endif; ?>

                    <div class="detail-box">
                        <?php if ( $service_name ) : ?>
                        <h4><?php echo esc_html( $service_name ); ?></h4>
                        <?php endif; ?>

                        <?php if ( $service_description ) : ?>
                        <p><?php echo esc_html( $service_description ); ?></p>
                        <?php endif; ?>

                        <?php if ( ! empty( $service_button['url'] ) && ! empty( $service_button['title'] ) ) : ?>
                        <a href="<?php echo esc_url( $service_button['url'] ); ?>"
                            target="<?php echo esc_attr( $service_button['target'] ?: '_self' ); ?>">
                            <?php echo esc_html( $service_button['title'] ); ?>
                            <i class="fa fa-long-arrow-right" aria-hidden="true"></i>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- end service section -->

<!-- about section -->
<?php if ( get_field('about_section_off') ) : ?>
<?php
$about_title       = get_field('about_title');
$about_description = get_field('about_description');
$about_button      = get_field('about_button');
$about_image       = get_field('aboutimage');
?>
<section class="about_section layout_padding-bottom">
    <div class="container">
        <div class="row">

            <div class="col-md-6">
                <div class="detail-box">
                    <?php if ( $about_title ) : ?>
                    <div class="heading_container">
                        <h2><?php echo esc_html( $about_title ); ?></h2>
                    </div>
                    <?php endif; ?>

                    <?php if ( $about_description ) : ?>
                    <p><?php echo esc_html( $about_description ); ?></p>
                    <?php endif; ?>

                    <?php if ( $about_button ) : ?>
                    <a href="<?php echo esc_url( $service_button['url'] ); ?>">
                        <?php echo esc_html( $about_button['title'] ); ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="col-md-6">
                <?php if ( ! empty( $about_image['url'] ) ) : ?>
                <div class="img-box">
                    <img src="<?php echo esc_url( $about_image['url'] ); ?>"
                        alt="<?php echo esc_attr( $about_image['alt'] ); ?>">
                </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</section>
<?php endif; ?>
<!-- end about section -->


<!-- cta section start -->
<?php if ( get_field('cta_section_off') ) : ?>
<?php
    $cat_image = get_field('cat_image');
    $cta_title = get_field('cta_title');
    $cta_description = get_field('cta_description');
    $cta_button = get_field('cta_button');
    ?>
<section class="server_section">
    <div class="container ">
        <div class="row">
            <div class="col-md-6">
                <?php if(!empty($cat_image['url'])): ?>
                <div class="img-box">
                    <img src="<?php echo $cat_image['url']; ?>" alt="">
                    <div class="play_btn">
                        <button>
                            <i class="fa fa-play" aria-hidden="true"></i>
                        </button>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <div class="detail-box">
                    <?php if($cta_title || $cta_description ): ?>
                    <div class="heading_container">
                        <?php if(!empty($cta_title)): ?>
                        <h2><?php echo $cta_title; ?></h2>
                        <?php endif; ?>

                        <?php if(!empty($cta_description)): ?>
                        <p> <?php echo $cta_description; ?></p>
                        <?php endif; ?>
                    </div>
                    <?php endif; ?>
                    <?php if(!empty($cta_button)): ?>
                    <a href="<?php echo $cta_button['url']; ?>">
                        <?php echo $cta_button['title']; ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<!-- end cta section -->

<!-- price section -->

<section class="price_section layout_padding">
    <div class="container">
        <?php
  $pricing_title = get_field('pricing_title');
  if ($pricing_title):
  ?>
        <div class="heading_container heading_center">
            <h2><?php echo esc_html($pricing_title); ?></h2>
        </div>
        <?php endif; ?>

        <div class="price_container">
            <?php if (have_rows('price_table')): ?>
            <?php while (have_rows('price_table')): the_row();
        $enter_price = get_sub_field('enter_price');
        $package_type = get_sub_field('package_type');
        $pricing_button = get_sub_field('pricing_button');
      ?>
            <div class="box">
                <div class="detail-box">
                    <?php if ($enter_price): ?>
                    <h2><?php echo esc_html($enter_price); ?></h2>
                    <?php endif; ?>

                    <?php if ($package_type): ?>
                    <h6><?php echo esc_html($package_type); ?></h6>
                    <?php endif; ?>

                    <?php if (have_rows('item_repeater')): ?>
                    <ul class="price_features">
                        <?php while (have_rows('item_repeater')): the_row();
                  $include_item = get_sub_field('include_iteam');
                  if ($include_item):
                ?>
                        <li><?php echo esc_html($include_item); ?></li>
                        <?php endif; endwhile; ?>
                    </ul>
                    <?php endif; ?>
                </div>

                <?php if ($pricing_button): ?>
                <div class="btn-box">
                    <a href="<?php echo esc_url($pricing_button['url']); ?>">
                        <?php echo esc_html($pricing_button['title']); ?>
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>

</section>

<!-- price section -->

<!-- client section -->
<section class="client_section ">
    <?php
        $sec_testimonials_title = get_field('sec_testimonials_title');
        $sec_testimonials_description = get_field('sec_testimonials_description');
        if($sec_testimonials_title || $sec_testimonials_description ): ?>
    <div class="container">
        <div class="heading_container heading_center">
            <?php

        if($sec_testimonials_title):
        ?>
            <h2>
                <?php echo $sec_testimonials_title; ?>
            </h2>
            <?php endif; ?>
            <?php if($sec_testimonials_description): ?>
            <p>
                <?php echo $sec_testimonials_description; ?>
            </p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <div class="container px-0">
        <div id="customCarousel2" class="carousel slide" data-ride="carousel">

            <div class="carousel-inner">
                <?php
      $args = array(
        'post_type' => 'testimonial',
        'posts_per_page' => -1,
        'post_status' => 'publish'
      );
      $testimonial_query = new WP_Query($args);
      $is_first = true;

      if($testimonial_query->have_posts()):
        while($testimonial_query->have_posts()): $testimonial_query->the_post();

          $client_designation = get_field('client_designation');
          $client_description = get_field('client_description');
          $quote__icon = get_field('quote__icon');
          $thumbnail = get_the_post_thumbnail_url(get_the_ID(), 'medium');
      ?>
                <div class="carousel-item <?php echo $is_first ? 'active' : ''; ?>">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-10 mx-auto">
                                <div class="box">
                                    <div class="img-box">
                                        <?php if($thumbnail): ?>
                                        <img src="<?php echo esc_url($thumbnail); ?>"
                                            alt="<?php echo esc_attr(get_the_title()); ?>">
                                        <?php endif; ?>
                                    </div>
                                    <div class="detail-box">
                                        <div class="client_info">
                                            <div class="client_name">
                                                <h5><?php the_title(); ?></h5>
                                                <?php if($client_designation): ?>
                                                <h6><?php echo esc_html($client_designation); ?></h6>
                                                <?php endif; ?>
                                            </div>
                                            <?php if($quote__icon): ?>
                                            <i class="<?php echo esc_attr($quote__icon); ?>" aria-hidden="true"></i>
                                            <?php endif; ?>
                                        </div>
                                        <?php if($client_description): ?>
                                        <p><?php echo esc_html($client_description); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php
        $is_first = false;
        endwhile;
        wp_reset_postdata();
      endif;
      ?>
            </div>

            <div class="carousel_btn-box">
                <a class="carousel-control-prev" href="#customCarousel2" role="button" data-slide="prev">
                    <i class="fa fa-angle-left" aria-hidden="true"></i>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#customCarousel2" role="button" data-slide="next">
                    <i class="fa fa-angle-right" aria-hidden="true"></i>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
    </div>

</section>
<!-- end client section -->

<!-- contact section -->
<section class="contact_section layout_padding-bottom">
    <div class="container">
        <div class="heading_container heading_center">
            <h2>
                Get In Touch
            </h2>
        </div>
        <div class="row">
            <div class="col-md-8 col-lg-6 mx-auto">
                <div class="form_container">
                    <?php echo do_shortcode( '[contact-form-7 id="2e77d12" title="Home page form"]'); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end contact section -->
<?php
get_footer();
?>