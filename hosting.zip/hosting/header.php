<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->



<?php wp_head();?>
</head>

<body <?php body_class(  );?>>

  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
			<?php
			$header_logo = get_field('header_logo', 'options');
			$uplode_logo = get_field('uplode_logo', 'options');
			$phone_icon = get_field('phone_icon', 'options');
			$phone_number = get_field('phone_number', 'options');
			?>
			<?php  
			if ( ! empty( $header_logo ) ) : ?>
				<a class="navbar-brand" href="<?php echo home_url(); ?>">
					<span><?php echo esc_html( $header_logo ); ?></span>
				</a>
			<?php  
			elseif ( ! empty( $uplode_logo['url'] ) ) : ?>
				<a class="navbar-brand" href="<?php echo home_url(); ?>">
					<img src="<?php echo esc_url( $uplode_logo['url'] ); ?>" alt="<?php echo esc_url( $uplode_logo['alt'] ); ?>">
				</a>
			<?php endif; ?>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">


			<?php
			wp_nav_menu( array(
				'theme_location' => 'menu_1',
				'menu_class'     => 'navbar-nav ml-auto',
				'container'      => false,
				'fallback_cb'    => false
			) );

?>

			<?php if(!empty($phone_number) && ($phone_icon)): ?>
            <div class="quote_btn-container">
              <!-- <form class="form-inline">
                <button class="btn   nav_search-btn" type="submit">
                  <i class="fa fa-search" aria-hidden="true"></i>
                </button>
              </form> -->
              <a href="tel:<?php echo $phone_number; ?>">
                <i class="<?php echo $phone_icon; ?>" aria-hidden="true"></i>
                <span>
                  <?php echo $phone_number; ?>
                </span>
              </a>
            </div>
			<?php endif; ?>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->