
  <!-- info section -->

  <section class="info_section layout_padding2" style="background-color:<?php the_field('footer_background_color','option'); ?>">
	
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="info_contact">
			<?php
			$footer_address = get_field('footer_address','option');
			$map_icon = get_field('map_icon','option');
			$enter_location = get_field('enter_location','option');
			$footer_phone_icon = get_field('footer_phone_icon','option');
			$enter_number = get_field('enter_number','option');
			$email_icon = get_field('email_icon','option');
			$enter_email = get_field('enter_email','option');
			$information = get_field('information','option');
			$footer_description = get_field('footer_description','option');
			$subscribe = get_field('subscribe','option');
			$copyright = get_field('copyright','option');
			// Repeater
			$social_repeaters = get_field('social_repeater','option');

			?>

			<?php if ( ! empty( $footer_address ) ) : ?>
			<h4><?php echo esc_html( $footer_address ); ?></h4>
			<?php endif; ?>

			<div class="contact_link_box">
			<?php if ( ! empty( $enter_location ) && ! empty( $map_icon ) ) : ?>
				<a href="#">
				<i class="<?php echo esc_attr( $map_icon ); ?>" aria-hidden="true"></i>
				<span><?php echo esc_html( $enter_location ); ?></span>
				</a>
			<?php endif; ?>

				<?php if ( ! empty( $footer_phone_icon ) && ! empty( $enter_number ) ) : ?>
              <a href="tel:<?php echo esc_html( $enter_number ); ?>">
                <i class="<?php echo esc_attr( $footer_phone_icon ); ?>" aria-hidden="true"></i>
					<span><?php echo esc_html( $enter_number ); ?></span>
              </a>
			  <?php endif; ?>

				<?php if ( ! empty( $enter_email ) && ! empty( $email_icon ) ) : ?>
              <a href="mailto:<?php echo esc_html( $enter_email ); ?>">
                <i class="<?php echo esc_html( $email_icon ); ?>" aria-hidden="true"></i>
				<span><?php echo esc_html( $enter_email ); ?></span>
              </a>
			  <?php endif; ?>

            </div>
          </div>
          <div class="info_social">
			<?php
			foreach($social_repeaters as $social_repeater){
				?>
				<?php if (!empty($social_repeater['enter_url']) && !empty($social_repeater['footer_social_icon'])): ?>
				<a href="<?php echo $social_repeater['enter_url']; ?>">
              <i class="<?php echo $social_repeater['footer_social_icon']; ?>" aria-hidden="true"></i>
            </a>
				<?php endif; ?>
			<?php
			}
			?>

          </div>
        </div>
        <div class="col-md-3">
          <div class="info_link_box">
            <h4>
              Links
            </h4>
            <div class="info_links">

                <?php dynamic_sidebar( 'sidebar_1' ); ?>
				
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="info_detail">

			<?php if ( ! empty( $information ) ) : ?>
			<h4><?php echo esc_html( $information ); ?></h4>
			<?php endif; ?>

			<?php if ( ! empty( $footer_description ) ) : ?>
            <p>
			<?php echo esc_html( $footer_description ); ?>
            </p>
			<?php endif; ?>

          </div>
        </div>
        <div class="col-md-3 mb-0">
			<?php if ( ! empty( $subscribe ) ) : ?>
			<h4><?php echo esc_html( $subscribe ); ?></h4>
			<?php endif; ?>

				<?php echo do_shortcode( '[contact-form-7 id="42bbdc1" title="footer form"]' ); ?>

        </div>
      </div>
    </div>
  </section>

  <!-- end info section -->
  <!-- footer section -->
  <footer class="footer_section" style="background-color:<?php the_field('footer_background_color','option'); ?>" >
    <div class="container">          
			<p>
			<?php
			$year = date('Y');
			if ( ! empty( $copyright ) ) {
				echo esc_html( $copyright );
			} else {
				echo "© $year All Rights Reserved | Shohag";
			}
			?>
			</p>       
    </div>
  </footer>
  <!-- footer section -->
<?php wp_footer();?>
</body>

</html>