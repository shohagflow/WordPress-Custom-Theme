<?php

function halim_active_plugin(){
	$plugins = array(

		// This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => __('One Click Demo Import','halim'), // The plugin name.
			'slug'               => 'one-click-demo-import', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
		array(
			'name'               => __('Widget Importer Exporter','halim'), // The plugin name.
			'slug'               => 'widget-importer-exporter', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
		array(
			'name'               => __('Contact form 7','halim'), // The plugin name.
			'slug'               => 'contact-form-7', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
        // This is an example of how to include a plugin bundled with a theme.
		array(
			'name'               => __('Font Awesome Field','halim'), // The plugin name.
			'slug'               => 'advanced-custom-fields-font-awesome', // The plugin slug (typically the folder name).
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
        array(
			'name'               => __('ACF Pro','halim'), // The plugin name.
			'slug'               => 'acf-pro', // The plugin slug (typically the folder name).
			'source'    => get_stylesheet_directory() . '/plugin/acf-pro.zip',
			'required'           => true, // If false, the plugin is only 'recommended' instead of required.
		),
        array(
            'name'      => __('Halim Custom Post','halim'),
            'slug'      => 'halim-custom-post',
			// 'source'    => get_stylesheet_directory() . '/plugin/halim-custom-post.zip', // The plugin source.
            'required'  => true,
        ),
            
	);


	$config = array(
		'id'           => 'halim_plugin_active',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'Halim Plugin Activation', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.

	);

	tgmpa( $plugins, $config );
}
add_action('tgmpa_register','halim_active_plugin');


