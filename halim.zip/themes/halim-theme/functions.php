<?php

// theme support
function shohag_theme_setup(){
    add_theme_support( 'title-tag' );
    add_theme_support( 'widgets');
    add_theme_support( 'post-thumbnails', array('gallery','post'));
    // load_theme_halim('wpdocs_theme', get_template_directory() . '/languages');

    add_theme_support('menus');
    function halim_theme_setup() {
        register_nav_menus( array(
            'primary_menu'   => __( 'Primary Menu', 'halim' ),
            'footer_menu'    => __( 'Footer Menu', 'halim' ),
        ) );
    }
    add_action( 'after_setup_theme', 'halim_theme_setup' );
}    

// css $ js file enqueue
function shohag_theme_scripts() {
    // css link
	wp_enqueue_style( 'poppins_font', "//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700",array(), '1.0.0', 'all'  );
    wp_enqueue_style( 'boostrap', get_template_directory_uri() . "/assets/css/bootstrap.min.css",array(), '1.0.0', 'all' );
    wp_enqueue_style( 'font_awsome', get_template_directory_uri() . "/assets/css/font-awesome.min.css",array(), '1.0.0', 'all' );
    wp_enqueue_style( 'magnific-popup', get_template_directory_uri() . "/assets/css/magnific-popup.css",array(), '1.0.0', 'all' );
    wp_enqueue_style( 'owl.carousel', get_template_directory_uri() . "/assets/css/owl.carousel.css",array(), '1.0.0', 'all' );
    wp_enqueue_style( 'style', get_template_directory_uri() . "/assets/css/style.css",array(), '1.0.0', 'all' );
    wp_enqueue_style( 'responsive', get_template_directory_uri() . "/assets/css/responsive.css",array(), '1.0.0', 'all' );
    wp_enqueue_style( 'style-theme', get_stylesheet_uri() );

    // js link
    wp_enqueue_script('popper', get_template_directory_uri() . '/assets/js/popper.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('owl.carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('jquery.magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('imageloaded', get_template_directory_uri() . '/assets/js/imageloaded.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('counterup', get_template_directory_uri() . '/assets/js/jquery.counterup.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('waypoints', get_template_directory_uri() . '/assets/js/waypoint.min.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0.0', true);
}
add_action( 'wp_enqueue_scripts', 'shohag_theme_scripts' );

// Theme option=====================
add_action('acf/init', function() {
    if (function_exists('acf_add_options_page')) {

        // Main options page
        acf_add_options_page(array(
            'page_title'    => 'Theme Options',
            'menu_title'    => 'Theme Options',
            'menu_slug'     => 'theme-option',
            'capability'    => 'edit_posts',
            'redirect'      => false
        ));

        // Header settings sub page
        acf_add_options_sub_page(array(
            'page_title'    => 'Theme Header Settings',
            'menu_title'    => 'Header',
            'parent_slug'   => 'theme-option',
        ));

        // About Settings sub page
        acf_add_options_sub_page(array(
            'page_title'    => 'About Settings',
            'menu_title'    => 'About',
            'parent_slug'   => 'theme-option',
        ));

        // FAQ & Skill sub page
        acf_add_options_sub_page(array(
            'page_title'    => 'FAQ & Skill',
            'menu_title'    => 'FAQ & Skill',
            'parent_slug'   => 'theme-option',
            'redirect'      => false
        ));

        // CTA sub page
        acf_add_options_sub_page(array(
            'page_title'    => 'CTA',
            'menu_title'    => 'CTA',
            'parent_slug'   => 'theme-option',
            'redirect'      => false
        ));

        // Latest News sub page
        acf_add_options_sub_page(array(
            'page_title'    => 'Latest News',
            'menu_title'    => 'Latest News',
            'parent_slug'   => 'theme-option',
            'redirect'      => false
        ));

        // Contact sub page
        acf_add_options_sub_page(array(
            'page_title'    => 'Contact',
            'menu_title'    => 'Contact',
            'parent_slug'   => 'theme-option',
            'redirect'      => false
        ));

        // Footer option page
        acf_add_options_sub_page(array(
            'page_title'    => 'Footer',
            'menu_title'    => 'Footer',
            'parent_slug'   => 'theme-option',
            'redirect'      => false
        ));
    }
});

/**
 * Add a sidebar.
 */
function shohag_theme_slug_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Main Sidebar', 'halim' ),
		'id'            => 'sidebar_1',
		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'halim' ),
		'before_widget' => ' <div class="single-sidebar">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>',
	) );
    register_sidebar( array(
		'name'          => __( 'Footer 1', 'halim' ),
		'id'            => 'footer_1',
		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'halim' ),
		'before_widget' => '  <div class="single-footer footer-logo">',
		'after_widget'  => '</div>',
		'before_title'  => '<h3>',
		'after_title'   => '</h3>',
	) );
    register_sidebar( array(
		'name'          => __( 'Footer 2', 'halim' ),
		'id'            => 'footer_2',
		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'halim' ),
		'before_widget' => ' <div class="single-footer">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>',
	) );
    register_sidebar( array(
		'name'          => __( 'Footer 3', 'halim' ),
		'id'            => 'footer_3',
		'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'halim' ),
		'before_widget' => ' <div class="single-footer">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'shohag_theme_slug_widgets_init' );

// single comment 
function shohag_comment_placeholders( $fields ) {
    $fields['author'] = str_replace(
        '<input',
        '<input placeholder="Enter Your Name"',
        $fields['author']
    );
    $fields['email'] = str_replace(
        '<input id="email" name="email" type="text"',
        '<input type="email" placeholder="email@example.com" id="email" name="email"',
        $fields['email']
    );
    $fields['url'] = str_replace(
        '<input id="url" name="url" type="text"',
        '<input type="url" placeholder="https://shohag.com" id="url" name="url"',
        $fields['url']
    );

    return $fields;
}
add_filter( 'comment_form_default_fields', 'shohag_comment_placeholders' );

// Comment ফিল্ডের placeholder
function custom_comment_textarea_placeholder( $defaults ) {
    $defaults['comment_field'] = 
        '<p class="comment-form-comment">
            <label for="comment">Comment</label>
            <textarea id="comment" name="comment" cols="45" rows="5" placeholder="Write your comment here..." required></textarea>
        </p>';
    return $defaults;
}
add_filter( 'comment_form_defaults', 'custom_comment_textarea_placeholder' );
// tgm file installation
require_once get_template_directory(  ) .'/inc/class-tgm-plugin-activation.php';
require_once get_template_directory(  ) .'/inc/halim-plugin-activation.php';
require_once get_template_directory(  ) .'/inc/demo-import.php';
require_once get_template_directory(  ) .'/inc/halim-acf-data.php';

