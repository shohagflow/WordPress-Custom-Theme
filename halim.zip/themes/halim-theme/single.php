<?php get_header();?>
<section class="breadcumb-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="breadcumb">
                    <h4><?php the_title();?></h4>
                    <ul>
                        <li><a href="<?php site_url(  );?>"></a>Home</li> /
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="blog-single pt-100 pb-100">
    <div class="container">
        <div class="row">
            <div class="col-xl-8">
                <h2><?php the_title();?></h2>
                <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                <p><?php the_content();?></p>
                <!-- comment section start -->
                <div class="comments">
                    <?php
                    // Your post content
                    the_content();

                    // Show comments if open or if there is at least one comment
                    if ( comments_open() || get_comments_number() ) :
                        comments_template();
                    endif;
                    ?>

                </div>
                <!-- comment section end -->
            </div>
            <div class="col-xl-4">
                <div class="single-sidebar">
                    <?php
                    if ( is_active_sidebar( 'sidebar_1' ) ){
                        dynamic_sidebar('sidebar_1');
                    }
                   ?>
                </div>
            </div>
        </div>
</section>
<?php get_footer();?>