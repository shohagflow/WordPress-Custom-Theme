<?php
/**
 * The template for displaying Comments.
 */
comment_form(); 

?>
