<?php
/*
Template Name: About Page
*/
get_header( );

?>
<section class="breadcumb-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="breadcumb">
                    <h4><?php the_title();?></h4>
                    <ul>
                        <li><a href="<?php site_url(  );?>"></a>Home</li> /
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- About Area Start -->
<section class="about-area pt-100 pb-100" id="about">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="about">
                    <div class="page-title">
                        <h4><?php the_title();?></h4>
                    </div>
                    <p><?php the_content();?></p>
                </div>
            </div>
            <div class="col-md-5">
                <?php
                  if( class_exists('ACF') ) {
                     $featufes= get_field('featufe');
                     foreach($featufes as $featufe){
                        ?>
                <div class="single_about">
                    <i class="fa <?php echo $featufe['icon'];?>"></i>
                    <h4><?php echo $featufe['title'];?></h4>
                    <p><?php echo $featufe['description'];?> </p>
                </div>
                <?php
                     }                    
                  }
                  ?>
            </div>
        </div>
    </div>
</section>
<!-- About Area End -->

<?php get_footer(  );?>