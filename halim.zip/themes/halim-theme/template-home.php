<?php
/*
Template Name: Home Page
*/

get_header(  );?>
<!-- Slider Area Start -->
<section class="slider-area" id="home">
    <div class="slider owl-carousel">
        <?php
            $args=array(
               'post_type'=>'slider',
               'posts_per_page'=> 3
            );
         $query = new WP_Query( $args );
         while ( $query->have_posts() ) { 
            $query->the_post();
            $image = get_field('slider_image');
            ?>
        <?php
            if( $image )
                $url = $image['url'];
                ?>
        <div class="single-slide" style="background-image:url('<?php echo esc_url($url); ?>');">
            <div class="container">
                <div class="row">
                    <div class="col-xl-12">
                        <div class="slide-table">
                            <div class="slide-tablecell">
                                <?php if(class_exists('ACF')){
                                    $sub_title= get_field('sub_title');
                                    $button_url=get_field('button_url');
                                    $button_text=get_field('button_text');
                                }
                                ?>
                                <h4><?php echo $sub_title?></h4>
                                <h2><?php the_title();?></h2>
                                <p><?php the_content();?></p>
                                <?php
                                 if ($button_url){
                                ?>
                                <a href="<?php echo $button_url['url'];?>"
                                    class="box-btn"><?php echo $sub_title;?><i
                                        class="fa fa-angle-double-right"></i></a>
                                <?php }?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
      }
      wp_reset_postdata();
        ?>
    </div>
</section>
<!-- Slider Area Start -->
<!-- About Area Start -->
<section class="about-area pt-100 pb-100" id="about">
    <div class="container">
        <div class="row section-title">
            <div class="col-md-6 text-right">
                <?php
                if(class_exists('ACF')){
                    $about_section=get_field('about_section','option');
                    $about_content=get_field('about_content','option');
                }
               
                ?>
                <h3><span><?php echo $about_section['sub_title']; ?></span><?php echo $about_section['title']; ?></h3>
            </div>
            <div class="col-md-6">
                <p><?php echo $about_section['description']; ?></p>
            </div>
        </div>
        <div class="row">
            <div class="col-md-7">
                <div class="about">
                    <div class="page-title">
                        <?php
                        if(class_exists('ACF')){
                $about_content=get_field('about_content','option');
                $about_feature=get_field('about_feature','option');
                        }
                ?>
                        <h4><?php echo $about_content['title']; ?></h4>
                    </div>
                    <p><?php echo $about_content['description']; ?> </p>

                    <a href="<?php echo $about_content['button_url']; ?>"
                        class="box-btn"><?php echo $about_content['button_text']; ?><i
                            class="fa fa-angle-double-right"></i></a>
                </div>
            </div>
            <div class="col-md-5">
                <?php
                if(class_exists('ACF')){
                    $about_features=get_field('about_feature','option');
                }

                foreach($about_features as $about_feature){       
                ?>
                <div class="single_about">
                    <i class="fa <?php echo $about_feature['icon']; ?>"></i>
                    <h4> <?php echo $about_feature['title']; ?></h4>
                    <p> <?php echo $about_feature['description']; ?></p>
                </div>
                <?php
                }
                ?>
            </div>
        </div>
    </div>
</section>
<!-- About Area End -->
<!-- FAQ Area End -->
<section class="choose">
    <div class="container">
        <div class="row pt-100 pb-100">
            <div class="col-md-6">
                <div class="faq">
                    <div class="page-title">
                        <h4><?php the_field('faq__title','option');?></h4>
                    </div>
                    <div class="accordion" id="accordionExample">
                        <?php
                        if (have_rows('faqs', 'option')):
                            $i = 0;
                            while (have_rows('faqs', 'option')): the_row();
                                $i++;
                                $question = get_sub_field('faq__question', 'option');
                                $answer = get_sub_field('faq__description', 'option');
                                $headingId = 'heading' . $i;
                                $collapseId = 'collapse' . $i;
                                $showClass = ($i === 1) ? 'show' : '';
                                $collapsedClass = ($i === 1) ? '' : 'collapsed';
                                $ariaExpanded = ($i === 1) ? 'true' : 'false';
                        ?>
                        <div class="card">
                            <div class="card-header" id="<?php echo esc_attr($headingId); ?>">
                                <h5 class="mb-0">
                                    <button class="btn btn-link <?php echo $collapsedClass; ?>" type="button"
                                        data-toggle="collapse" data-target="#<?php echo esc_attr($collapseId); ?>"
                                        aria-expanded="<?php echo esc_attr($ariaExpanded); ?>"
                                        aria-controls="<?php echo esc_attr($collapseId); ?>">
                                        <?php echo esc_html($question); ?>
                                    </button>
                                </h5>
                            </div>

                            <div id="<?php echo esc_attr($collapseId); ?>" class="collapse <?php echo $showClass; ?>"
                                aria-labelledby="<?php echo esc_attr($headingId); ?>" data-parent="#accordionExample">
                                <div class="card-body">
                                    <?php echo wp_kses_post($answer); ?>
                                </div>
                            </div>
                        </div>
                        <?php endwhile;
                        else:
                            echo '<p>No FAQs found.</p>';
                        endif;
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="skills">
                    <?php
                
                ?>
                    <div class="page-title">
                        <h4><?php the_field('our_skill_title','option');?></h4>
                    </div>
                    <?php
                $our_skill= get_field('our_skill','option');
                foreach($our_skill as $skill){
                    ?>
                    <div class="single-skill">
                        <h4><?php echo $skill['title'];?></h4>
                        <div class="progress-bar" role="progressbar" style="width:<?php echo $skill['number'];?>%;"
                            aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"><?php echo $skill['number'];?>
                        </div>
                    </div>
                    <?php
                }
                ?>


                </div>
            </div>
        </div>
    </div>
</section>
<!-- FAQ Area End -->
<!-- Services Area Start -->
<section class="services-area pt-100 pb-50" id="services">
    <div class="container">
        <div class="row section-title">
            <div class="col-md-6 text-right">
                <h3><span>who we are?</span> our services</h3>
            </div>
            <div class="col-md-6">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.d </p>
            </div>
        </div>
        <div class="row">
            <?php
            $args=array(
               'post_type'=>'service',
               'posts_per_page'=> 6
            );

         $query = new WP_Query( $args );
         while ( $query->have_posts() ) { 
            $query->the_post();

            ?>
            <div class="col-lg-4 col-md-6">
                <!-- Single Service -->
                <div class="single-service">
                    <i class="<?php the_field('service_icon');?> "></i>
                    <h4><?php the_title();?> </h4>
                    <p><?php the_content();?>
                    </p>
                </div>
            </div>

            <?php
         }
         wp_reset_postdata(  );
            ?>
        </div>
    </div>
</section>
<!-- Services Area End -->

<!-- Counter Area End -->
<section class="counter-area">
    <div class="container-fluid">
        <div class="row">
            <?php
$args = array(
    'post_type' => 'counters',
    'posts_per_page' => 4
);

$query = new WP_Query($args);

    while ($query->have_posts()) {
        $query->the_post();
        ?>
            <div class="col-md-3">
                <div class="single-counter">
                    <h4>
                        <i class="<?php echo esc_attr(get_field('counter_icon')); ?>"></i>
                        <span class="counter"><?php echo esc_html(get_field('counter_number')); ?></span>
                        <span><?php the_title(); ?></span>
                    </h4>
                </div>
            </div>
            <?php
    }
    wp_reset_postdata();

?>

        </div>
    </div>
</section>
<!-- Counter Area End -->
<!-- Team Area Start -->
<section class="team-area pb-100 pt-100" id="team">
    <div class="container">
        <div class="row section-title">
            <div class="col-md-6 text-right">
                <h3><span>who we are?</span> creative team</h3>
            </div>
            <div class="col-md-6">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.d </p>
            </div>
        </div>
        <div class="row">
            <?php
        $args = array(
            'post_type' => 'teams',
            'posts_per_page' => 3
        );
        $query = new WP_Query($args);
            while ($query->have_posts()) {
                $query->the_post();
                $image=get_field('team_image');
                ?>
            <div class="col-md-4">
                <div class="single-team">
                    <img src="<?php echo $image['url'] ;?>" alt="" />
                    <div class="team-hover">
                        <div class="team-content">
                            <h4>
                                <?php the_field('team_member_name'); ?>
                                <span><?php the_field('team_designation'); ?></span>
                            </h4>
                            <ul>
                                <?php 
                                        if(get_field('facebook_link')){
                                        ?>
                                <li><a href="<?php the_field('facebook_link')?>"><i class="fa fa-facebook"></i></a></li>
                                <?php
                                        }
                                        ?>
                                <?php 
                                        if(get_field('twitter')){
                                        ?>
                                <li><a href="<?php the_field('twitter')?>"><i class="fa fa-twitter"></i></a></li>
                                <?php
                                        }
                                        ?>
                                <?php 
                                        if(get_field('linkedin')){
                                        ?>
                                <li><a href="<?php the_field('linkedin')?>"><i class="fa fa-linkedin"></i></a></li>
                                <?php
                                        }
                                        ?>
                                <?php 
                                        if(get_field('instagram')){
                                        ?>
                                <li><a href="<?php the_field('instagram')?>"><i class="fa fa-instagram"></i></a></li>
                                <?php
                                        }
                                        ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <?php
            }
            wp_reset_postdata(  );
                
                ?>
        </div>
    </div>
</section>
<!-- Team Area End -->

<!-- Testimonials Area Start -->
<section class="testimonial-area pb-100 pt-100" id="testimonials">
    <div class="container">
        <div class="row section-title white-section">
            <div class="col-md-6 text-right">
                <h3><span>who we are?</span> what client say</h3>
            </div>
            <div class="col-md-6">
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry typesetting industry.d </p>
            </div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="testimonials owl-carousel">
                    <?php
                $args = array(
            'post_type' => 'testmonails',
            'posts_per_page' => 3
        );
        $query = new WP_Query($args);
            while ($query->have_posts()) {
                $query->the_post();
                $image=get_field('picture');
                ?>

                    <div class="single-testimonial">
                        <div class="testi-img">
                            <img src="<?php echo $image['url']; ?>" alt="" />
                        </div>
                        <p>" <?php the_field('description')?>"</p>

                        <h4><span><?php the_field('name')?></span><span><?php the_field('designation')?></span></h4>
                    </div>
                    <?php
            }
            wp_reset_postdata(  );
                ?>

                </div>
            </div>
        </div>
    </div>
</section>
<!-- Testimonilas Area End -->
<!-- Latest News Area Start -->
<section class="blog-area pb-100 pt-100" id="blog">
    <div class="container">
        <div class="row section-title">
            <div class="col-md-6 text-right">
                <h3><span><?php the_field('latest_subtitle','option');?></span>
                    <?php the_field('latest_title','option');?></h3>
            </div>
            <div class="col-md-6">
                <p><?php the_field('latest_description','option');?> </p>
            </div>
        </div>
        <div class="row">
            <?php
            $args = array(
            'post_type' => 'post',
            'posts_per_page' => 3
        );
        $query = new WP_Query($args);
            while ($query->have_posts()) {
                $query->the_post();
                ?>
            <div class="col-md-4">
                <div class="single-blog">
                    <?php the_post_thumbnail();?>
                    <div class="post-content">
                        <div class="post-title">
                            <h4><a href="<?php the_permalink(  );?>"><?php the_title();?></a></h4>
                        </div>
                        <div class="pots-meta">
                            <ul>
                                <li><a href="#">25 oct 2018</a></li>
                                <li><a href="#">admin</a></li>
                            </ul>
                        </div>
                        <p><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                        <a href="<?php the_permalink(  );?>" class="box-btn">read more <i
                                class="fa fa-angle-double-right"></i></a>
                    </div>
                </div>
            </div>
            <?php
            }
            wp_reset_postdata(  );

          ?>

        </div>
    </div>
</section>
<!-- Latest News Area End -->
<?php get_footer();?>