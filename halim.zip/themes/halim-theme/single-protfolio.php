<?php get_header();?>
<!-- Header Area Start -->
<section class="breadcumb-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="breadcumb">
                    <h4><?php the_title();?></h4>
                    <ul>
                        <li><a href="<?php echo site_url();?>"></a>Home</li> /
                        <li><?php the_title();?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="portfolio-single pt-100 pb-100">
    <div class="container">
        <div class="row">
            <div class="col-xl-8">
                <?php
                  $image=get_field('protfolio_image');
                  $single_page_description=get_field('single_page_description');
              
                  ?>
                <h2><?php the_title();?></h2>
                <img src="<?php echo $image['url'];?>" alt="">
                <p><?php echo $single_page_description;?> </p>
                <div class="row">
                    <div class="col-xl-12">
                        <h4>Gallery</h4>
                    </div>
                    <div class="col-xl-4">
                        <div class="project-gallery d-flex">

                            <?php
                if( $project_gallery=get_field('project_gallery')){
                  foreach($project_gallery as $gallery){
                     ?>
                     <img src="<?php echo $gallery['url'];?>" alt="">
                     <?php
                    }
                }else{
                  ?>
                  <h5>Empty is gallery</h5>
                  <?php
                }               
                 ?>
                        </div>
                    </div>

                </div>
                <br><br>
                <div class="row">
                    <div class="col-xl-12">
                        <h4>project overview</h4>
                        <?php
                        $video_url=get_field('video_url');
                        if($video_url){                           
                           echo $video_url;                         
                        }else{
                           ?>
                          <h6>Not Add Video</h6>
                           <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="portfolio-sidebar">
                    <?php
                     $technology_used = get_field('technology_used');
                     if( $technology_used ){
                     ?>
                    <h4><?php echo $technology_used; ?></h4>
                    <?php
                     }else{
                        ?>
                    <h5>Not Wirte title</h5>
                    <?php
                     }
                     ?>

                    <ul>
                        <?php 
                        if($technology_names=get_field('technology_name')){
                           foreach($technology_names as $technology_name){
                              ?>
                        <li><i class="fa fa-arrow-right"></i> <?php echo $technology_name['tecnology_repeat'];?></li>
                        <?php
                           }
                        }else{
                          ?>
                        <h6>Not Add </h6>
                        <?php
                     
                        }                
                     ?>
                    </ul>
                </div>
                <div class="portfolio-sidebar">
                    <?php
                  $project_features=get_field('project_features');
                  if($project_features){
                     ?>
                    <h4><?php echo $project_features ;?></h4>
                    <?php
                  }else{
                     ?>
                    <h6>Not Add Title</h6>
                    <?php
                  }
                  ?>

                    <ul>
                        <?php
                     
                     if($project_features_nmaes=get_field('project_features_nmae')){
                        foreach($project_features_nmaes as $project_features_nmae){
                           ?>
                        <li><i class="fa fa-arrow-right"></i>
                            <?php echo $project_features_nmae['project_features_repeat'];?></li>
                        <?php
                     }                   
                      }else{
                        ?>
                        <h6>Not Add </h6>
                        <?php
                      }
                     ?>

                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer();?>