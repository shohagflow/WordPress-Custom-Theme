<?php
get_header( );

?>
<section class="breadcumb-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="breadcumb">
                    <h1>404</h1>
                    <ul>
                        <li><a href="<?php echo site_url();?>"></a>Home</li> /
                        <li>404</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<?php get_footer();?>