<?php
// Parent theme er style load korar jonno
function halim_child_enqueue_styles() {
    wp_enqueue_style('halim-parent-style', get_template_directory_uri() . '/style.css');
}
add_action('wp_enqueue_scripts', 'halim_child_enqueue_styles');


