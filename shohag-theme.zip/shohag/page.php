<?php

 get_header(); 

 ?>

<div class="main_page_content">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
        <?php get_template_part('template-parts/pages/page'); ?>
    </div>
</div>

<?php get_footer(); ?>


