<?php
/*
   Template Name: Home
*/
get_header();
?>
      <!-- Slider Area Start -->
      <section class="slider-area" id="home">
      <div class="slider owl-carousel">
         <?php if( have_rows('slider_repeater') ): ?>
            <?php while( have_rows('slider_repeater') ): the_row(); 
                  $slider_sub_heading = get_sub_field('slider_sub_heading');
                  $slider_heading = get_sub_field('slider_heading');
                  $slider_description = get_sub_field('slider_description');
                  $button_text = get_sub_field('button_text');
                  $button_url = get_sub_field('button_url');
                  $slider_image = get_sub_field('slider_image');
            ?>
                  <div class="single-slide" style="background-image:url('<?php echo esc_url($slider_image['url']); ?>')">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
                        <div class="row">
                              <div class="col-xl-12">
                                 <div class="slide-table">
                                    <div class="slide-tablecell">
                                          <?php if ($slider_sub_heading): ?>
                                             <h4><?php echo esc_html($slider_sub_heading); ?></h4>
                                          <?php endif; ?>

                                          <?php if ($slider_heading): ?>
                                             <h2><?php echo esc_html($slider_heading); ?></h2>
                                          <?php endif; ?>

                                          <?php if ($slider_description): ?>
                                             <p><?php echo esc_html($slider_description); ?></p>
                                          <?php endif; ?>

                                          <?php if ($button_text && $button_url): ?>
                                             <a href="<?php echo esc_url($button_url); ?>" class="box-btn">
                                                <?php echo esc_html($button_text); ?> <i class="fa fa-angle-double-right"></i>
                                             </a>
                                          <?php endif; ?>
                                    </div>
                                 </div>
                              </div>
                        </div>
                     </div>
                  </div>
            <?php endwhile; ?>
         <?php endif; ?>
      </div>
      </section>
      <!-- Slider Area End -->
      <!-- About Area Start -->
      <section class="about-area pt-100 pb-100" id="about">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
         <?php if( get_field('about_title') || get_field('about_description') ): ?>
            <div class="row section-title">
               <div class="col-md-12 text-center">
                     <?php if( get_field('about_title') ): ?>
                        <h3><?php the_field('about_title'); ?></h3>
                     <?php endif; ?>
                     
                     <?php if( get_field('about_description') ): ?>
                        <p><?php the_field('about_description'); ?></p>
                     <?php endif; ?>
               </div>
            </div>
         <?php endif; ?>

            <div class="row">
               <div class="col-md-7">
                  <div class="about">
                     <div class="page-title">

                        <?php if(get_field('welcome_title')):?>
                        <h4><?php the_field('welcome_title'); ?></h4>
                        <?php endif; ?>
                     </div>

                        <?php if(get_field('welcome_description')):?>
                        <p><?php the_field('welcome_description'); ?></p>
                        <?php endif; ?>
                        <?php
                        $welcome_button_url  = get_field('welcome_button_url');
                        $welcome_button_text = get_field('welcome_button_text');
                        ?>

                        <?php if ($welcome_button_url && $welcome_button_text): ?>
                           <a href="<?php echo esc_url($welcome_button_url); ?>" class="box-btn">
                              <?php echo esc_html($welcome_button_text); ?> <i class="fa fa-angle-double-right"></i>
                           </a>
                        <?php endif; ?>
                  </div>
               </div>
               <div class="col-md-5">
                  <?php if( have_rows('our_vission_section') ): ?>

                           <?php while( have_rows('our_vission_section') ): the_row(); 
                              $vission_icon = get_sub_field('vission_icon');
                              $vission_title = get_sub_field('vission_title');
                              $vission_description = get_sub_field('vission_description');
                           ?>
                     <div class="single_about">
                              <?php if ($vission_icon): ?>
                                 <i class="<?php echo esc_attr($vission_icon); ?>"></i>
                              <?php endif; ?>

                              <?php if ($vission_title): ?>
                                 <h4><?php echo esc_html($vission_title); ?></h4>
                              <?php endif; ?>

                              <?php if ($vission_description): ?>
                                 <p><?php echo esc_html($vission_description); ?></p>
                              <?php endif; ?>
                              </div>
                           <?php endwhile; ?>
                     </div>
                  <?php endif; ?>
            </div>
         </div>
      </section>
      <!-- About Area End -->
      <!-- faq Area skill start -->
       <?php 
$skill_background_image = get_field('skill_background_image');
$bgg_image_url = $skill_background_image ? esc_url($skill_background_image['url']) : '';
?>
      <section class="choose"
          style="background-image: url('<?php echo $bgg_image_url; ?>'); background-size: cover; background-position: center; background-repeat: no-repeat;"
      >
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
            <div class="row pt-100 pb-100">
               <div class="col-md-6">
                  <div class="faq">
                     <div class="page-title"> 
                        <?php if ($faq_title = get_field('faq_title')): ?>
                           <h4><?php echo esc_html($faq_title); ?></h4>
                        <?php endif; ?>
                     </div>

                     <div class="accordion" id="accordionExample">
                     <?php if( have_rows('faqs_repeater') ): ?>
                        <div class="accordion" id="accordionExample">
                           <?php 
                           $i = 0;
                           while( have_rows('faqs_repeater') ): the_row(); 
                                 $faqs_title = get_sub_field('faqs_title');
                                 $faqs_description = get_sub_field('faqs_description');

                                 // Unique IDs
                                 $heading_id = 'heading' . $i;
                                 $collapse_id = 'collapse' . $i;
                                 $show_class = ($i === 0) ? 'show' : '';
                                 $expanded = ($i === 0) ? 'true' : 'false';
                           ?>
                           <div class="card">
                                 <div class="card-header" id="<?php echo esc_attr($heading_id); ?>">
                                    <h5 class="mb-0">
                                       <button class="btn btn-link <?php echo ($i !== 0) ? 'collapsed' : ''; ?>" 
                                                type="button" 
                                                data-toggle="collapse" 
                                                data-target="#<?php echo esc_attr($collapse_id); ?>" 
                                                aria-expanded="<?php echo esc_attr($expanded); ?>" 
                                                aria-controls="<?php echo esc_attr($collapse_id); ?>">
                                             <?php echo esc_html($faqs_title); ?>
                                       </button>
                                    </h5>
                                 </div>

                                 <div id="<?php echo esc_attr($collapse_id); ?>" 
                                    class="collapse <?php echo esc_attr($show_class); ?>" 
                                    aria-labelledby="<?php echo esc_attr($heading_id); ?>" 
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                       <?php echo esc_html($faqs_description); ?>
                                    </div>
                                 </div>
                           </div>
                           <?php $i++; endwhile; ?>
                        </div>
                     <?php endif; ?>
                     </div>
                  </div>
               </div>
<!-- slills area -->
               <div class="col-md-6">
                  <div class="skills">
                     <div class="page-title">
                        <?php if ($our_skill_title = get_field('our_skill_title')): ?>
                           <h4><?php echo esc_html($our_skill_title); ?></h4>
                        <?php endif; ?>
                     </div>

                     <?php if( have_rows('skills_repeater') ): ?>
                        <?php while( have_rows('skills_repeater') ): the_row(); 
                           $skills_name = get_sub_field('skills_name');
                           $skills_persentang = get_sub_field('skills_persentang');
                        ?>
                           <div class="single-skill">
                                 <?php if($skills_name ): ?>
                                    <h4><?php echo esc_html($skills_name); ?></h4>
                                 <?php endif; ?>

                                 <?php if($skills_persentang): ?>
                                    <div class="progress-bar" role="progressbar" 
                                          style="width: <?php echo esc_attr($skills_persentang); ?>%;" 
                                          aria-valuenow="<?php echo esc_attr($skills_persentang); ?>" 
                                          aria-valuemin="0" aria-valuemax="100">
                                       <?php echo esc_html($skills_persentang); ?>%
                                    </div>
                                 <?php endif; ?>
                           </div>
                        <?php endwhile; ?>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- faq Area skill End -->
      <!-- Services Area Start -->
      <section class="services-area pt-100 pb-50" id="services">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
         <?php if( get_field('service_title') || get_field('service_description') ): ?>
            <div class="row section-title">
               <div class="col-md-12 text-center">
                  <?php if( get_field('service_title') ): ?>
                  <h3><?php the_field('service_title'); ?></h3>
               <?php endif; ?>
                  <?php if( get_field('service_description') ): ?>
                  <p><?php the_field('service_description'); ?></p>
               <?php endif; ?>
               </div>
            </div>
            <?php endif; ?>

            <div class="row">
            <?php if( have_rows('services_item') ): ?>
               <?php while( have_rows('services_item') ): the_row(); 
                  $service_icon = get_sub_field('service_icon');
                  $service_name = get_sub_field('service_name');
                  $service_description = get_sub_field('service_description');
               ?>
               <div class="col-lg-4 col-md-6">
                  <!-- Single Service -->
                  <div class="single-service">
                     <?php if($service_icon): ?>
                        <i class="<?php echo esc_attr($service_icon); ?>"></i>
                     <?php endif; ?>

                     <?php if($service_name): ?>
                        <h4><?php echo esc_html($service_name); ?></h4>
                     <?php endif; ?>

                     <?php if($service_description): ?>
                        <p><?php echo esc_html($service_description); ?></p>
                     <?php endif; ?>
                  </div>
               </div>
               <?php endwhile; ?>
            <?php endif; ?>
            </div>
         </div>
      </section>
      <!-- Services Area End -->
      
      <!-- Counter Area End -->
      <section class="counter-area">
         <div class="container-fluid">
            <div class="row">
               <?php if( have_rows('counter_repeate') ): ?>
                  <?php while( have_rows('counter_repeate') ): the_row(); 
                     $counter_icon = get_sub_field('counter_icon');
                     $counter_number = get_sub_field('counter_number');
                     $counter_name = get_sub_field('counter_name');
                  ?>
                     <div class="col-md-3">
                     <div class="single-counter">
                           <h4>
                              <?php if($counter_icon): ?>
                                 <i class="<?php echo esc_attr($counter_icon); ?>"></i>
                              <?php endif; ?>
                              <?php if($counter_number): ?>
                                 <span class="counter"><?php echo esc_html($counter_number); ?></span>
                              <?php endif; ?>
                              <?php if($counter_name): ?>
                                 <?php echo esc_html($counter_name); ?>
                              <?php endif; ?>
                           </h4>
                     </div>
                     </div>
                  <?php endwhile; ?>
               <?php endif; ?>
            </div>
         </div>
      </section>
      <!-- Counter Area End -->
      <!-- Team Area Start -->
<?php 
$team_background_image = get_field('team_background_image');
$bg_image_url = $team_background_image ? esc_url($team_bg_image['url']) : '';
?>

<section class="team-area pb-100 pt-100" id="team" 
    style="background-image: url('<?php echo $bg_image_url; ?>'); background-size: cover; background-position: center; background-repeat: no-repeat;">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
      <?php if( get_field('team_titel') || get_field('team_description') ): ?>
        <div class="row section-title">
            <div class="col-md-12 text-center">
                <?php if( get_field('team_titel') ): ?>
                    <h3><?php the_field('team_titel'); ?></h3>
                <?php endif; ?>

                <?php if( get_field('team_description') ): ?>
                    <p><?php the_field('team_description'); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

<div class="row">
  <?php if( have_rows('team_repeater') ): ?>
    <?php while( have_rows('team_repeater') ): the_row(); 
      $mumber_name = get_sub_field('mumber_name');
      $team_designation = get_sub_field('team_designation');
      $team_image = get_sub_field('team_image');
    ?>
    <div class="col-md-4">
      <div class="single-team">
        <?php if( $team_image ): ?>
          <img src="<?php echo esc_url($team_image['url']); ?>" alt="<?php echo esc_attr($mumber_name); ?>" />
        <?php else: ?>
          <img src="<?php echo get_template_directory_uri(); ?>/assets/img/team/default.jpg" alt="default image" />
        <?php endif; ?>

        <div class="team-hover">
          <div class="team-content">
            <?php if( $mumber_name || $team_designation ): ?>
              <h4>
                <?php echo esc_html($mumber_name); ?>
                <?php if( $team_designation ): ?>
                  <span><?php echo esc_html($team_designation); ?></span>
                <?php endif; ?>
              </h4>
            <?php endif; ?>

            <?php if( have_rows('social_repeater') ): ?>
              <ul>
                <?php while( have_rows('social_repeater') ): the_row(); 
                  $team_icon = get_sub_field('team_icon');
                  $team_url = get_sub_field('team_url');
                ?>
                  <?php if( $team_icon && $team_url ): ?>
                    <li>
                      <a href="<?php echo esc_url($team_url); ?>" target="_blank">
                        <i class="<?php echo esc_attr($team_icon); ?>"></i>
                      </a>
                    </li>
                  <?php endif; ?>
                <?php endwhile; ?>
              </ul>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
    <?php endwhile; ?>
  <?php endif; ?>
</div>

    </div>
</section>

      <!-- Team Area End -->
     
      <!-- Testimonials Area Start -->
       <?php 
$test_background_image = get_field('test_background_image');
$testi_image_url = $test_background_image ? esc_url($test_background_image['url']) : '';
?>
      <section class="testimonial-area pb-100 pt-100" id="testimonials"
          style="background-image: url('<?php echo $testi_image_url; ?>'); background-size: cover; background-position: center; background-repeat: no-repeat;">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
            <?php if( get_field('test_title') || get_field('test_description') ): ?>
            <div class="row section-title">
               <div class="col-md-12 text-center">
                  <?php if( get_field('test_title') ): ?>
                  <h3><?php the_field('test_title'); ?></h3>
               <?php endif; ?>
                  <?php if( get_field('test_description') ): ?>
                  <p><?php the_field('test_description'); ?></p>
               <?php endif; ?>
               </div>
            </div>
            <?php endif; ?>
         </div>
         <div class="container-fluid">
            <div class="row">
               <div class="col-md-12">
                  <div class="testimonials owl-carousel">

                     <?php if( have_rows('testimonails') ): ?>
                        <?php while( have_rows('testimonails') ): the_row(); 
                           $client_image = get_sub_field('client_image');
                           $client_description = get_sub_field('client_description');
                           $client_name = get_sub_field('client_name');
                           $client_designation = get_sub_field('client_designation');
                        ?>
                        <div class="single-testimonial">
                           <?php if ($client_image): ?>
                              <div class="testi-img">
                                 <img src="<?php echo esc_url($client_image['url']); ?>" alt="<?php echo esc_attr($testimonial_name); ?>" />
                              </div>
                           <?php endif; ?>
                           
                           <?php if ($client_description): ?>
                              <p>" <?php echo esc_html($client_description); ?> "</p>
                           <?php endif; ?>

                           <?php if ($client_name): ?>
                              <h4><?php echo esc_html($client_name); ?> 
                                 <?php if ($client_designation): ?>
                                    <span><?php echo esc_html($client_designation); ?></span>
                                 <?php endif; ?>
                              </h4>
                           <?php endif; ?>
                        </div>
                        <?php endwhile; ?>
                     <?php endif; ?>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Testimonilas Area End -->
      <!-- Latest News Area Start -->
      <section class="blog-area pb-100 pt-100" id="blog">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
            <?php if( get_field('blog_title') || get_field('blog_description') ): ?>
            <div class="row section-title">
               <div class="col-md-12 text-center">
                  <?php if( get_field('blog_title') ): ?>
                  <h3><?php the_field('blog_title'); ?></h3>
               <?php endif; ?>
                  <?php if( get_field('blog_description') ): ?>
                  <p><?php the_field('blog_description'); ?></p>
               <?php endif; ?>
               </div>
            </div>
            <?php endif; ?>
            <div class="row">
               <?php
               $args = array(
                  'post_type'      => 'post',
                  'posts_per_page' => 3, 
               );
               $blog_query = new WP_Query($args);
               ?>
               <?php if ($blog_query->have_posts()): ?>
                  <?php while ($blog_query->have_posts()): $blog_query->the_post(); ?>
                     <div class="col-md-4">
                           <div class="single-blog">
                              <?php if (has_post_thumbnail()): ?>
                                 <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title_attribute(); ?>" />
                              <?php endif; ?>

                              <div class="post-content">
                                 <div class="post-title">
                                       <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                 </div>

                                 <div class="pots-meta">
                                       <ul>
                                          <li><a href="#"><?php echo get_the_date(); ?></a></li>
                                          <li><a href="#"><?php the_author(); ?></a></li>
                                       </ul>
                                 </div>

                                 <p><?php echo wp_trim_words(get_the_content(), 20, '...'); ?></p>

                                 <a href="<?php the_permalink(); ?>" class="box-btn">read more <i class="fa fa-angle-double-right"></i></a>
                              </div>
                           </div>
                     </div>
                  <?php endwhile; ?>
                  <?php wp_reset_postdata(); ?>
               <?php else: ?>
                  <p>No blog posts found.</p>
               <?php endif; ?>
            </div>
         </div>
      </section>
      <!-- Latest News Area End -->
   <?php
   get_footer();
   ?>