<?php
/*
   Template Name: About 
*/
get_header();
get_template_part('inc/breadcumb'); 
?>
<!-- About Area Start -->
<section class="about-area pt-100 pb-100" id="about">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
               <div class="row section-title">
               <div class="col-md-12 text-center">
                  <?php if( get_field('ab_about_titel') ): ?>
                  <h3><?php the_field('ab_about_titel'); ?></h3>
               <?php endif; ?>
                  <?php if( get_field('ab_description') ): ?>
                  <p><?php the_field('ab_description'); ?></p>
               <?php endif; ?>
               </div>
            </div>
            <div class="row">
               <div class="col-md-7">
                  <div class="about">
                     <div class="page-title">
                     <?php if ( get_field('about_welcome_title') ) : ?>
                        <h4><?php the_field('about_welcome_title'); ?></h4>
                     <?php endif; ?>
                     </div>
                     <?php if ( get_field('about_wellcome_description') ) : ?>
                        <p><?php the_field('about_wellcome_description'); ?></p>
                     <?php endif; ?>  
					<?php
					$about_button_url = get_field('about_button_url');
					$ab_button_text = get_field('ab_button_text');
					?>

					<?php if ($about_button_url && $ab_button_text): ?>
						<a href="<?php echo esc_url($about_button_url); ?>" class="box-btn">
							<?php echo esc_html($ab_button_text); ?> <i class="fa fa-angle-double-right"></i>
						</a>
					<?php endif; ?>

                  </div>
               </div>
               <div class="col-md-5">
               <?php if( have_rows('about_our_vissions') ): ?>
                  <?php while( have_rows('about_our_vissions') ): the_row(); ?>
                     <?php 
                           $ab_icon = get_sub_field('ab_icon'); 
                           $ab_vission_titel = get_sub_field('ab_vission_titel'); 
                           $ab_description = get_sub_field('ab_description'); 
                     ?>
                     <div class="single_about">
                           <?php if( $ab_icon ): ?>
                              <i class="<?php echo esc_attr($ab_icon); ?>"></i>
                           <?php endif; ?>

                           <?php if( $ab_vission_titel ): ?>
                              <h4><?php echo esc_html($ab_vission_titel); ?></h4>
                           <?php endif; ?>

                           <?php if( $ab_description ): ?>
                              <p><?php echo esc_html($ab_description); ?></p>
                           <?php endif; ?>
                     </div>
                  <?php endwhile; ?>
               <?php endif; ?>
               </div>
            </div>
         </div>
      </section>
      <!-- About Area End -->
<?php
get_footer();
?>