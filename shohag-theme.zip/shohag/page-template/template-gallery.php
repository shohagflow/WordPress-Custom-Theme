<?php
/*
   Template Name: Gallery
*/
get_header();
get_template_part('inc/breadcumb'); 
?>
<section class="gallery-area pt-100 pb-100">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
        <div class="row">
            <?php if( have_rows('gallery_item') ): ?>
                <?php while( have_rows('gallery_item') ): the_row();
                    $gallery_titel = get_sub_field('gallery_titel');  
                    $gallery_image = get_sub_field('gallery_image'); 
                    $zoom_image = get_sub_field('zoom_image'); 

                    // Image validation and extraction
                    $gallery_image_url = $gallery_image ? $gallery_image['url'] : '';
                    $gallery_image_alt = $gallery_image ? $gallery_image['alt'] : '';
                    $zoom_image_url = $zoom_image ? $zoom_image['url'] : '';
                ?>
                    <div class="col-xl-4">
                        <div class="single-gallery">
                            <?php if( $gallery_image_url ): ?>
                                <img src="<?php echo esc_url($gallery_image_url); ?>" alt="<?php echo esc_attr($gallery_image_alt); ?>">
                            <?php endif; ?>
                            
                            <div class="gallery-hover">
                                <div class="gallery-content">
                                    <?php if( $gallery_titel && $zoom_image_url ): ?>
                                        <h3>
                                            <a href="<?php echo esc_url($zoom_image_url); ?>" class="gallery">
                                                <i class="fa fa-plus"></i> <?php echo esc_html($gallery_titel); ?>
                                            </a>
                                        </h3>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php get_footer();?>