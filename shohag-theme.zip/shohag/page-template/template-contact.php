<?php
/*
   Template Name: Contact
*/
get_header();
get_template_part('inc/breadcumb'); 
?>
<!-- Contact Us Area End -->
<section class="contact-area pb-100 pt-100" id="contact">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
            <div class="row">
               <div class="col-md-10 mx-auto">
				<style>
					.contact-details {
						list-style: none;
						padding: 0;
						margin: 0;
					}
				</style>

				<div class="row text-center">
				   <?php if( have_rows('contact_repeater') ): ?>
					  <?php while( have_rows('contact_repeater') ): the_row(); ?>
						 <?php
							$contact_page_icon     = get_sub_field('contact_page_icon');
							$contact_page_title    = get_sub_field('contact_page_titel');
							$contact_page_address  = get_sub_field('contact_page_address');
							$contact_address_url   = get_sub_field('contact_address_url');
							$contact_phone_number  = get_sub_field('contact_phone_number');
							$contact_email         = get_sub_field('contact_email');
						 ?>
						 <div class="col-md-4">
							<div class="contact-address">
							   <?php if( $contact_page_icon ): ?>
								  <i class="<?php echo esc_attr($contact_page_icon); ?>"></i>
							   <?php endif; ?>

							   <?php if( $contact_page_title ): ?>
								  <h4><?php echo esc_html($contact_page_title); ?></h4>
							   <?php endif; ?>

							   <ul class="contact-details" style="list-style: none; padding: 0; margin: 0;">
								  <?php if( $contact_page_address && $contact_address_url ): ?>
									 <li>
										<a href="<?php echo esc_url($contact_address_url); ?>" target="_blank">
										   <?php echo esc_html($contact_page_address); ?>
										</a>
									 </li>
								  <?php elseif( $contact_page_address ): ?>
									 <li><?php echo esc_html($contact_page_address); ?></li>
								  <?php endif; ?>

								  <?php if( $contact_phone_number ): ?>
									 <li>
										<a href="tel:<?php echo esc_attr($contact_phone_number); ?>">
										   <?php echo esc_html($contact_phone_number); ?>
										</a>
									 </li>
								  <?php endif; ?>

								  <?php if( $contact_email ): ?>
									 <li>
										<a href="mailto:<?php echo esc_attr($contact_email); ?>">
										   <?php echo esc_html($contact_email); ?>
										</a>
									 </li>
								  <?php endif; ?>
							   </ul>
							</div>
						 </div>
					  <?php endwhile; ?>
				   <?php endif; ?>
				</div>

                  <div class="row">
                     <div class="col-md-7">
                        <div class="contact-form">
<?php echo do_shortcode('[contact-form-7 id="64ae31d" title="contact"]'); ?>

                        </div>
                     </div>
                     <div class="col-md-5">
                     
                     
					<?php 
					$embed_url = get_field('map_url');
					if ($embed_url): ?>
						<div class="google-map">
							<iframe 
								src="<?php echo esc_url($embed_url); ?>" 
								width="100%" 
								height="500" 
								style="border:0;" 
								allowfullscreen 
								loading="lazy" 
								referrerpolicy="no-referrer-when-downgrade">
							</iframe>
						</div>
					<?php endif; ?>


                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Contact Us Area End -->
<?php get_footer();?>