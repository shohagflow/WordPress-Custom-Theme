<?php
/*
   Template Name: Service
*/
get_header();
get_template_part('inc/breadcumb'); 
?>
<!-- Services Area Start -->
<section class="services-area pt-100 pb-50" id="services">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
            <div class="row">
            <?php if( have_rows('service_page_repeater') ): ?>
            <?php while( have_rows('service_page_repeater') ): the_row(); 
               $service_page_icon = get_sub_field('service_page_icon');
               $service_page_name = get_sub_field('service_page_name');
               $service_page_description = get_sub_field('service_page_description');
            ?>
               <div class="col-lg-4 col-md-6">
                  <!-- Single Service -->
                  <div class="single-service">
                  <?php if( $service_page_icon ): ?>
                     <i class="<?php echo esc_attr($service_page_icon); ?>"></i>
                  <?php endif; ?>

                  <?php if( $service_page_name ): ?>
                     <h4><?php echo esc_html($service_page_name); ?></h4>
                  <?php endif; ?>

                  <?php if( $service_page_description ): ?>
                     <p><?php echo esc_html($service_page_description); ?></p>
                  <?php endif; ?>
                  </div>
               </div>
            <?php endwhile; ?>
            <?php endif; ?>
         </div>
      </section>
      <!-- Services Area End -->
  <?php get_footer();?>