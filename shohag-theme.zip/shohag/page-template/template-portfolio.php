<?php
/*
Template Name: Protfolio
*/
get_header();
get_template_part('inc/breadcumb'); 
?>

<!-- Protfolio Area Start -->
<section class="projects-area pb-100 pt-100" id="projects">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
  
    <!-- Category Filter Buttons -->
    <div class="row">
      <div class="col-xl-12">
        <div class="portfolio-menu mb-40 text-center">
          <button class="active" data-filter="*"><?php echo esc_html__('All', 'shohag'); ?></button>

          <?php
          $cats = get_terms(array(
            'taxonomy' => 'categorie_port',
            'hide_empty' => false
          ));

          if (!is_wp_error($cats) && !empty($cats)) {
            foreach ($cats as $cat) {
              echo '<button data-filter=".' . esc_attr($cat->slug) . '">' . esc_html($cat->name) . '</button>';
            }
          }
          ?>
        </div>
      </div>
    </div>

    <!-- Portfolio Items -->
    <div class="row grid no-gutters">
      <?php
      $args = array(
          'post_type' => 'portfolio',
          'posts_per_page' => -1,
      );
      $query = new WP_Query($args);

      while ($query->have_posts()) {
          $query->the_post();

          // Taxonomy class generate
          $terms = get_the_terms(get_the_ID(), 'categorie_port');
          $term_classes = '';
          if ($terms && !is_wp_error($terms)) {
              foreach ($terms as $term) {
                  $term_classes .= ' ' . esc_attr($term->slug);
              }
          }
      ?>
      <div class="col-md-4 grid-item<?php echo $term_classes; ?>">
        <div class="single-portfolio">
          <?php if (has_post_thumbnail()) : ?>
            <?php the_post_thumbnail('full'); ?>
          <?php endif; ?>
          <div class="portfolio-hover">
            <div class="portfolio-content">
              <h3>
                <a href="<?php the_permalink(); ?>">
                  <i class="fa fa-link"></i>
                  <?php the_title(); ?>
                  <span><?php the_field('subtitle'); ?></span>
                </a>
              </h3>
            </div>
          </div>
        </div>
      </div>
      <?php } wp_reset_postdata(); ?>
    </div>
  </div>
</section>
<!-- Protfolio Area End -->

<?php get_footer(); ?>
