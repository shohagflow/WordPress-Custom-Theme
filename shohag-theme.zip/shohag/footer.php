     
 <!-- CTA Area Start -->
      <section class="cta">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
            <div class="row">
               <div class="col-md-6">
                  <?php
                  $cta_titel = get_field('cta_titel','option');
                  $cta_description = get_field('cta_description','option');
                  $cta_button_text = get_field('cta_button_text','option');
                  $cta_btn_url = get_field('cta_btn_url','option');
                  ?>
                  <h4><?php echo $cta_titel; ?></h4>
                  <p><?php echo $cta_description; ?></p>
               </div>
               <div class="col-md-6 text-center">
                  <a href="<?php echo $cta_btn_url;?>" class="box-btn"><?php echo $cta_button_text;?><i class="fa fa-angle-double-right"></i></a>
               </div>
            </div>
         </div>
      </section>
<!-- CTA Area End -->
<!-- Footer Area End -->
      <footer class="footer-area pt-50 pb-50">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
               <div class="row">
         <div class="col-lg-3 col-md-6">
            <?php
               $footer_text_logo = get_field('footer_text_logo', 'option'); 
               $footer_logo = get_field('footer_logo', 'option'); 
               $footer_description = get_field('footer_description', 'option');
            ?>
            <?php if ( $footer_logo || $footer_text_logo ): ?>
               <div class="single-footer footer-logo-image">
                  <?php if ( $footer_logo ): ?>
                     <img class="footer_logo_style" src="<?php echo esc_url($footer_logo['url']); ?>" alt="<?php echo esc_attr($footer_logo['alt']); ?>" />
                  <?php elseif ( $footer_text_logo ): ?>
                     <h3><?php echo esc_html($footer_text_logo); ?></h3>
                  <?php endif; ?>

                  <p><?php echo esc_html($footer_description); ?></p>
               </div>
            <?php endif; ?>
         </div>

         <div class="col-lg-2 col-md-6">
         <?php if(is_active_sidebar('footer_1')) {
                  dynamic_sidebar('footer_1');
               }
            ?>
         </div>
         <div class="col-lg-4 col-md-6">
         <?php if(is_active_sidebar('footer_2')) {
                  dynamic_sidebar('footer_2');
               }
            ?>
         </div>
<!-- 	contact us  -->
<div class="col-lg-3 col-md-6">
   <div class="single-footer contact-box">
      <?php
      $footer_contact_us_title = get_field('footer_contact_us_title', 'option');                
      ?>
      <h4><?php echo $footer_contact_us_title; ?></h4>

      <?php if( have_rows('footer_contact_info', 'option') ): ?>
         <ul>
            <?php while( have_rows('footer_contact_info', 'option') ): the_row(); 
               $footer_info_icon = get_sub_field('footer_info_icon');
               $enter_address     = get_sub_field('enter_address');
               $enter_number      = get_sub_field('enter_number');
               $enter_email       = get_sub_field('enter_email');
            ?>

               <?php if( $enter_address ): ?>
                  <li>
                     <?php if( $footer_info_icon ): ?><i class="<?php echo esc_attr($footer_info_icon); ?>"></i><?php endif; ?>
                     <?php echo esc_html($enter_address); ?>
                  </li>
               <?php endif; ?>

               <?php if( $enter_number ): ?>
                  <li>
                     <?php if( $footer_info_icon ): ?><i class="<?php echo esc_attr($footer_info_icon); ?>"></i><?php endif; ?>
                     <a href="tel:<?php echo esc_attr($enter_number); ?>">
                        <?php echo esc_html($enter_number); ?>
                     </a>
                  </li>
               <?php endif; ?>

               <?php if( $enter_email ): ?>
                  <li>
                     <?php if( $footer_info_icon ): ?><i class="<?php echo esc_attr($footer_info_icon); ?>"></i><?php endif; ?>
                     <a href="mailto:<?php echo esc_attr($enter_email); ?>">
                        <?php echo esc_html($enter_email); ?>
                     </a>
                  </li>
               <?php endif; ?>

            <?php endwhile; ?>
         </ul>
      <?php endif; ?>
   </div>
</div>

      </div>
      <div class="row copyright">
         <div class="col-md-6">
               <?php
               $copy_right_titel = get_field('copy_right_titel', 'option');                
               ?>
            <p><?php echo ($copy_right_titel); ?></p>
         </div>
         <div class="col-md-6 text-right">
            <?php if( have_rows('footer_social_medias', 'option') ): ?>
               <ul>
                  <?php while( have_rows('footer_social_medias', 'option') ): the_row(); 
                     $footer_media_icon = get_sub_field('footer_media_icon');
                     $footer_media_url = get_sub_field('footer_media_url');
                  ?>
                     <?php if( $footer_media_icon && $footer_media_url ): ?>
                        <li><a href="<?php echo esc_url($footer_media_url); ?>" target="_blank"><i class="<?php echo esc_attr($footer_media_icon); ?>"></i></a></li>
                     <?php endif; ?>
                  <?php endwhile; ?>
               </ul>
            <?php endif; ?>
         </div>
      </div>
   </div>
</footer>
<?php wp_footer();?>
</body>
</html>