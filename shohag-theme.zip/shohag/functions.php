<?php
require_once get_template_directory() . '/inc/tgm/active-plugins.php';
function shohag_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('menus'); 

    // Load theme translations
    load_theme_textdomain('shohag', get_template_directory() . '/languages');

    // Register navigation menus
    register_nav_menus(array(
        'header_menu' => __('Header Menu', 'shohag'),
        'footer_menu' => __('Footer Menu', 'shohag'),

    ));
}
add_action('after_setup_theme', 'shohag_setup');
add_action('init', function() {
    load_plugin_textdomain('acf', false, dirname(plugin_basename(__FILE__)) . '/languages');
});


function shohag_css_js_enqueue() {

    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css');
    wp_enqueue_style( 'font-poppins', '//fonts.googleapis.com/css?family=Poppins:300,400,500,600,700', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css', array(), '1.0.0', 'all');
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'magnific-popup', get_template_directory_uri() . '/assets/css/magnific-popup.css', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'owl-carousel', get_template_directory_uri() . '/assets/css/owl.carousel.css', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'style', get_template_directory_uri() . '/assets/css/style.css', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'responsive', get_template_directory_uri() . '/assets/css/responsive.css', array(), '1.0.0', 'all' );
    wp_enqueue_style( 'style-theme', get_stylesheet_uri() );

    wp_enqueue_script( 'popper', get_template_directory_uri() . '/assets/js/popper.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'magnific-popup', get_template_directory_uri() . '/assets/js/jquery.magnific-popup.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'isotope', get_template_directory_uri() . '/assets/js/isotope.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'imageloaded', get_template_directory_uri() . '/assets/js/imageloaded.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'counterup', get_template_directory_uri() . '/assets/js/jquery.counterup.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'waypoint', get_template_directory_uri() . '/assets/js/waypoint.min.js', array('jquery'), '1.0.0', true );
    wp_enqueue_script( 'main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '1.0.0', true );

}   
add_action('wp_enqueue_scripts', 'shohag_css_js_enqueue');
// Register Sidebar

function shohag_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Main Sidebar', 'shohag' ),
        'id'            => 'sidebar_1',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'shohag' ),
        'before_widget' => '<div class="single-sidebar">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer 1', 'shohag' ),
        'id'            => 'footer_1',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'shohag' ),
        'before_widget' => '<div class="single-footer footer-logo">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer 2', 'shohag' ),
        'id'            => 'footer_2',
        'description'   => __( 'Widgets in this area will be shown on all posts and pages.', 'shohag' ),
        'before_widget' => '<div class="single-footer">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );
    }
    add_action( 'widgets_init', 'shohag_widgets_init' );
//  ACF Theme option
if( function_exists('acf_add_options_page') ) {
	acf_add_options_page(array(
		'page_title' 	=> 'Theme Options', 'shohag',
		'menu_title'	=> 'Theme Options', 'shohag',
		'menu_slug' 	=> 'theme-options',
		'capability'	=> 'edit_posts',
		'redirect'		=> false
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Header ', 'shohag',
		'menu_title'	=> 'Header', 'shohag',
		'parent_slug'	=> 'theme-options',
	));
    
    acf_add_options_sub_page(array(
		'page_title' 	=> 'CTA ', 'shohag',
		'menu_title'	=> 'CTA', 'shohag',
		'parent_slug'	=> 'theme-options',
	));
	
    acf_add_options_sub_page(array(
		'page_title' 	=> 'Footer', 'shohag',
		'menu_title'	=> 'Footer', 'shohag',
		'parent_slug'	=> 'theme-options',
	));
	
}
// google map api key for acf
function my_acf_init() {
    acf_update_setting('google_api_key', 'AIzaSyAGLTRbkkKafy9bzizHJCVU8NU4zkYOnNM');
}
// theme option page add global

function apply_header_background_color() {
    $haeder_top_bg_color = get_field('header_top_background', 'option');
	$header_bg_color = get_field('main_header_background', 'option');
    $all_button_color = get_field('all_button_color', 'option');
	$contact_submit_button_color = get_field('contact_submit_button_color', 'option');
    $footer_background = get_field('footer_background', 'option');

    if ($haeder_top_bg_color) {
        echo '<style>
            .header-top {
                background-color: ' . esc_attr($haeder_top_bg_color) . ';
            }

        </style>';
    }
	    if ($header_bg_color) {
        echo '<style>
			    .header {
                background-color: ' . esc_attr($header_bg_color) . ';
            }
        </style>';
    }
		 if ($all_button_color) {
        echo '<style>
			    a.box-btn  {
                background-color: ' . esc_attr($all_button_color) . ';
            }
        </style>';
		 }
		 if ($contact_submit_button_color) {
        echo '<style>
			    .contact-form input[type="submit"]{
                background-color: ' . esc_attr($contact_submit_button_color) . ';
            }
        </style>';
    }
		if ($footer_background) {
        echo '<style>
			    .footer-area:before {
                background-color: ' . esc_attr($footer_background) . ';
            }
        </style>';
    }
    
}
add_action('wp_head', 'apply_header_background_color');

