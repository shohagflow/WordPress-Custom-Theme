<?php
/*
   Template Name: Blog
*/
get_header();
?>

<section class="blog-area pb-100 pt-100" id="blog">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
        <?php
        $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

        $args = array(
            'post_type'      => 'post',
            'posts_per_page' => 6,
            'paged'          => $paged,
        );

        $blog_query = new WP_Query($args);
        ?>

        <?php if ($blog_query->have_posts()) : ?>
            <div class="row">
                <?php while ($blog_query->have_posts()) : $blog_query->the_post(); ?>
                    <div class="col-md-4">
                        <div class="single-blog">
                            <?php if (has_post_thumbnail()) : ?>
                                <img src="<?php the_post_thumbnail_url('medium'); ?>" alt="<?php the_title_attribute(); ?>" />
                            <?php endif; ?>

                            <div class="post-content">
                                <div class="post-title">
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                </div>
                                <div class="pots-meta">
                                    <ul>
                                        <li><a href="<?php the_permalink(); ?>"><?php echo get_the_date(); ?></a></li>
                                        <li><a href="<?php the_permalink(); ?>"><?php the_author(); ?></a></li>
                                    </ul>
                                </div>
                                <p><?php echo wp_trim_words(get_the_content(), 20, '...'); ?></p>
                                <a href="<?php the_permalink(); ?>" class="box-btn">read more <i class="fa fa-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

            <!-- Pagination -->
            <div class="custom-pagination">
                <?php
                echo paginate_links(array(
                    'total'   => $blog_query->max_num_pages,
                    'current' => $paged,
                    'format'  => '?paged=%#%', // Important
                    'prev_text' => __('« Prev'),
                    'next_text' => __('Next »'),
                ));
                ?>
            </div>

            <?php wp_reset_postdata(); ?>
        <?php else : ?>
            <p>No blog posts found.</p>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>