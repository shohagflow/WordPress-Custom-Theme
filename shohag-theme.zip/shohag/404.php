<?php get_header(); ?>

<section class="error-area pt-70 pb-70">
    <div class="container text-center">
        <h1>404</h1>
        <h3><?php echo esc_html__('Oops! The page you are looking for does not exist.', 'halim'); ?></h3>
        <p><?php echo esc_html__('It looks like nothing was found at this location.', 'halim'); ?></p>
        <a href="<?php echo esc_url(home_url('/')); ?>" class="box-btn">
            <?php echo esc_html__('Back to Home', 'halim'); ?> <i class="fa fa-angle-double-right"></i>
        </a>
    </div>
</section>


<?php get_footer(); ?>
