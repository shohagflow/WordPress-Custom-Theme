<?php get_header(); ?>
<?php get_template_part('inc/breadcumb'); ?>

<section class="portfolio-single pt-100 pb-100">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
        <div class="row">
            <div class="col-xl-8">
                <h2><?php the_title(); ?></h2>

                <?php if ( has_post_thumbnail() ) : ?>
                    <img src="<?php echo get_the_post_thumbnail_url(); ?>" alt="">
                <?php endif; ?>

                <?php the_content(); ?>

                <div class="row">
                    <!-- Gallery Section -->
                    <?php
                    $gallery_title = get_field('gallery_titel');
                    $gallerys = get_field('project_gallery_image');

                    if ( $gallery_title || $gallerys ) : ?>
                        <div class="col-xl-12">
                            <?php if ( $gallery_title ) : ?>
                                <h4><?php echo esc_html( $gallery_title ); ?></h4>
                            <?php endif; ?>

                            <?php if ( $gallerys ) : ?>
                                <div class="row">
                                    <?php foreach ( $gallerys as $gallery ) : ?>
                                        <div class="col-xl-4">
                                            <div class="project-gallery">
                                                <img src="<?php echo esc_url( $gallery['url'] ); ?>" alt="<?php echo esc_attr( $gallery['alt'] ); ?>">
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

				<br>

                <!-- Video Section -->
                <?php
                $video_title = get_field('video_titel');
                $project_video_url = get_field('project_video_url');

                if ( $video_title || $project_video_url ) : ?>
                    <div class="row">
                        <div class="col-xl-12">
                            <?php if ( $video_title ) : ?>
                                <h4><?php echo esc_html( $video_title ); ?></h4>
                            <?php endif; ?>
                            <?php if ( $project_video_url ) : ?>
                                <div class="project-video">
                                    <?php echo $project_video_url; // Assuming embed or iframe ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-xl-4">
                <!-- Technology Section -->
                <?php
                $tech_title = get_field('technology_titel');
                $techs = get_field('technology_repeater');

                if ( $tech_title || $techs ) : ?>
                    <div class="portfolio-sidebar">
                        <?php if ( $tech_title ) : ?>
                            <h4><?php echo esc_html( $tech_title ); ?></h4>
                        <?php endif; ?>

                        <?php if ( $techs ) : ?>
                            <ul>
                                <?php foreach ( $techs as $tech ) : ?>
                                    <li><i class="fa fa-arrow-right"></i> <?php echo esc_html( $tech['technology_names'] ); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <!-- Features Section -->
                <?php
                $features_title = get_field('features_titel');
                $features = get_field('features_repeater');

                if ( $features_title || $features ) : ?>
                    <div class="portfolio-sidebar">
                        <?php if ( $features_title ) : ?>
                            <h4><?php echo esc_html( $features_title ); ?></h4>
                        <?php endif; ?>

                        <?php if ( $features ) : ?>
                            <ul>
                                <?php foreach ( $features as $feature ) : ?>
                                    <li><i class="fa fa-arrow-right"></i> <?php echo esc_html( $feature['features_names'] ); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php get_footer(); ?>
