<?php 
get_header();
get_template_part('inc/breadcumb'); 
?>
<section class="blog-single pt-100 pb-100">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
        <div class="row">
            <div class="col-xl-8">
                <h2><?php the_title();?></h2>
                <?php the_post_thumbnail();?>
                <?php the_content();?>
                <div class="comments">
                    <?php
                        if(comments_open()) {
                            comments_template();
                        }
                    ?>
                </div>
            </div>
            <div class="col-xl-4">
                <?php
                    if(is_active_sidebar('sidebar_1')) {
                        dynamic_sidebar('sidebar_1');
                    }
                ?>
            </div>
        </div>
    </div>
</section>
<?php get_footer();?>