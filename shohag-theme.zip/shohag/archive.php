<?php get_header(); ?>
<section class="breadcumb-area">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="breadcumb">
                    <h4><?php the_archive_title(); ?></h4>
                    <ul>
                        <li class="archive_title_style">
                            <a href="<?php echo site_url(); ?>"> <?php echo esc_html__('Home','shohag'); ?></a>
                        </li> / 
                        <li><?php the_archive_title(); ?></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="blog-area pb-100 pt-100" id="blog">
    <div class="container">
        <div class="row">
            <?php if (have_posts()) : ?>
                <?php while (have_posts()) : the_post(); ?>
                    <div class="col-md-4">
                        <div class="single-blog">
                            <div class="post-img">
                                <?php if (has_post_thumbnail()) : ?>
                                    <img src="<?php the_post_thumbnail_url(); ?>" alt="<?php the_title_attribute(); ?>" />
                                <?php endif; ?>
                            </div>
                            <div class="post-content">
                                <div class="post-title">
                                    <h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                </div>
                                <div class="pots-meta">
                                    <ul>
                                        <li><a href="#"><?php echo get_the_date(); ?></a></li>
                                        <li><?php the_category(', '); ?></li>
                                        <li><a href="#"><?php the_author(); ?></a></li>
                                    </ul>
                                </div>
                                <p><?php echo wp_trim_words(get_the_excerpt(), 20, '...'); ?></p>
                                <a href="<?php the_permalink(); ?>" class="box-btn">read more <i class="fa fa-angle-double-right"></i></a>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
        </div>

        <!--  Pagination -->
        <div class="row">
            <div class="col-md-12 text-center mt-5">
                <div class="pagination">
                    <?php
                    echo paginate_links(array(
                        'prev_text' => __('« Prev'),
                        'next_text' => __('Next »'),
                        'mid_size'  => 2,
                    ));
                    ?>
                </div>
            </div>
        </div>

        <?php else : ?>
            <p><?php esc_html_e('No posts found.', 'shohag'); ?></p>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>