<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
		   <?php
	// Get favicon URL from ACF
	$favicon_url = get_field('theme_favicon', 'option');

	if ($favicon_url):
	?>
	<link rel="icon" href="<?php echo esc_url($favicon_url['url']); ?>" type="image/png">
	<?php endif; ?>

 <?php wp_head();?>
   </head>
   <body <?php body_class();?>>
	   <?php
		$header_top_show = get_field('header_top_show','option');
		if ($header_top_show):
		?>
	   <section class="header-top">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
				<div class="row">
					<div class="col-md-6 col-sm-12">
						<div class="header-left">
                        <?php
                        $email_icon = get_field('email_icon','option'); 
                        $email_address = get_field('email_address','option'); 

                        $call_icone = get_field('call_icone','option'); 
                        $phone_number = get_field('phone_number','option'); 
                        ?>

                        <?php if ($email_icon && $email_address): ?>
                            <a href="mailto:<?php echo esc_attr($email_address); ?>">
                                <i class="<?php echo esc_attr($email_icon); ?>"></i> 
                                <?php echo esc_html($email_address); ?>
                            </a>
                        <?php endif; ?>

                        <?php if ($call_icone && $phone_number): ?>
                            <a href="tel:<?php echo esc_attr($phone_number); ?>">
                                <i class="<?php echo esc_attr($call_icone); ?>"></i> 
                                <?php echo esc_html($phone_number); ?>
                            </a>
                        <?php endif; ?>

						</div>
					</div>
					<div class="col-md-6 col-sm-12 text-right">
						<div class="header-social">
                            <?php
                            $header_social_medias = get_field('header_social_media', 'option');

                            if ($header_social_medias) {
                                foreach ($header_social_medias as $header_social_media) {
                                    $social_url = $header_social_media['header_social_url'];
                                    $social_icon = $header_social_media['header_social_icon'];

                                    if ($social_url && $social_icon) {
                                        ?>
                                        <a href="<?php echo esc_url($social_url); ?>" target="_blank" rel="noopener noreferrer">
                                            <i class="<?php echo esc_attr($social_icon); ?>"></i>
                                        </a>
                                        <?php
                                    }
                                }
                            }
                            ?>
						</div>
					</div>
				</div>
			</div>
	   </section>
	   <?php endif; ?>
      <!-- Header Area Start -->
      <header class="header header-fixed">
			<?php
			$container_width = get_field('theme_container_width','option'); 
			if ($container_width && is_numeric($container_width)) {
				$container_width .= 'px'; 
			}
			?>
			<div class="custom-container" style="max-width: <?php echo esc_attr($container_width); ?>; width: 100%; margin: 0 auto;">
            <div class="row">
               <div class="col-xl-12">
                  <nav class="navbar navbar-expand-md navbar-light">
                    <?php
                    $text_logo = get_field('text_logo', 'option'); 
                    $logo_image = get_field('logo_image', 'option'); 
                    ?>

                    <a class="navbar-brand" href="<?php echo esc_url(site_url()); ?>">
                        <?php if ($logo_image): ?>
                            <img src="<?php echo esc_url($logo_image['url']); ?>" alt="<?php echo esc_attr($logo_image['alt']); ?>">
                        <?php elseif ($text_logo): ?>
                            <?php echo esc_html($text_logo); ?>
                        <?php else: ?>
                            Shohag
                        <?php endif; ?>
                    </a>


                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse ml-auto mainmenu justify-content-end" id="navbarNav">
                        <?php
                           wp_nav_menu(array(
                              'theme_location' => 'header_menu',
                              'menu_class' => 'navbar-nav ml-auto'
                           ));
                        ?>
                     </div>
                  </nav>
               </div>
            </div>
         </div>
      </header>
      <!-- Header Area end -->